Date:	06/18/2014


Contact:
	David Rowe
	ROWETEL
	david#rowetel.com
	
	Richard Barnich
	rbarmich@comcast.net
	rbarnich at SKYPE

File:
	MFG-SM1000B.zip
Contents:
BOM-SM1000-REV-B1.PDF		PDF document containing the BOM for the assembly
BOM-SM1000-REV-B1.xls		Excel FIle of BOM-SM1000.sch
DRL-TAB-SM1000-REV-B1.pdf	Drill Table info for SM1000.brd
GERBER-SM1000-REV-B1.PDF			PDF document of Gerber plots
LOC-SM1000-REV-B1.PDF	PDF document with part locations for the assembly
LOC-SM1000-REV-B!.XLS	EXCEL FILE OF LOCATION INFORMATION
SCH-SM1000-REV-B1.PDF	PDF document with schematic for the assembly
README.PDF		This file. 

NOTES:
Y or Yes in the Generic column of the BOM indicates that the part may be substituted with any part that meets the part definition.
Y in the ROHS column of the BOM indicates that the part must meet ROHS requirements.
All parts MUST be ROHS compliant.


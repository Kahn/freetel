Date:	05/05/2016


Contact:
	David Rowe
	ROWETEL
	david#rowetel.com
	
	Richard Barnich
	rbarmich@comcast.net
	rbarnich at SKYPE

File:
	MFG-SM2000-a.zip
Contents:
AST-SM2000-F.PDF	Top Assembly File
BOM-SM2000-F.CSV	CSV document containing the BOM for the assembly
BOM-SM2000-F.PDF	PDF document containing the BOM for the assembly
BOM-SM2000-F.xls	Excel FIle of BM-SM1000.sch
GBR-SM2000-A.PDF
LOC-SM2000-F.CSV	CSV document with part locations for the assembly
LOC-SM2000-F.PDF	PDF document with part locations for the assembly
LOC-SM2000-F.XLS	EXCEL FILE OF LOCATION INFORMATION
SCH-SM2000-F.PDF	PDF document with schematic for the assembly

_MFG-README.PDF		This file. 

NOTES:
Y or Yes in the Generic column of the BOM indicates that the part may be substituted with any part that meets the part definition.
Y in the ROHS column of the BOM indicates that the part must meet ROHS requirements.
All parts MUST be ROHS compliant.


Date:	06/026/15


Contact:
	David Rowe
	ROWETEL
	david#rowetel.com
	
	Richard Barnich
	rbarmich@comcast.net
	rbarnich at SKYPE

File:
	MFG-SM1000-E.zip
Contents:
ASB-SM1000-E.PDF	Bottom Assembly file
AST-SM1000-E.PDF	Top Assembly File
BOM-SM1000-E.PDF	PDF document containing the BOM for the assembly
BOM-SM1000-E.xls	Excel FIle of BM-SM1000.sch
LOC-SM1000-E.PDF	PDF document with part locations for the assembly
LOC-SM1000-E.XLS	EXCEL FILE OF LOCATION INFORMATION
SCH-SM1000-E.PDF	PDF document with schematic for the assembly

README.PDF		This file. 

NOTES:
Y or Yes in the Generic column of the BOM indicates that the part may be substituted with any part that meets the part definition.
Y in the ROHS column of the BOM indicates that the part must meet ROHS requirements.
All parts MUST be ROHS compliant.


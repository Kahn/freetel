Date:	05/01/2014


Contact:
	David Rowe
	ROWETEL
	david#rowetel.com
	
	Richard Barnich
	rbarmich@comcast.net
	rbarnich at SKYPE

File:
	SM1000A.zip
Contents:
AST-SM1000.pdf		PDF of SM1000 top assembly
BOM-SM1000.PDF		PDF document containing the BOM for the assembly
BOM-SM1000.xls		Excel FIle of BOM-SM1000.sch
DIM-SM1000.pdf		PDF oof Dimensioned SM1000.brd
DRL-TAB-SM1000.pdf	Drill Table info for SM1000.brd
GERBER.PDF			PDF document of Gerber plots
LOC-SM1000.PDF	PDF document with part locations for the assembly
LOC-SM1000.XLS	EXCEL FILE OF LOCATION INFORMATION
README.PDF		This file. 
SCH-SM1000.PDF	PDF document with schematic for the assembly

NOTES:
Y or Yes in the Generic column of the BOM indicates that the part may be substituted with any part that meets the part definition.
Y in the ROHS column of the BOM indicates that the part must meet ROHS requirements.
All parts MUST be ROHS compliant.


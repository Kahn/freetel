Date:	01/14/15


Contact:
	David Rowe
	ROWETEL
	david#rowetel.com
	
	Richard Barnich
	rbarmich@comcast.net
	rbarnich at SKYPE

File:
	MFG-SM1000-D.zip
Contents:
ASB-SM1000-D.PDF		Bottom Assembly file
AST-SM1000-D.PDF		Top Assembly File
BOM-SM1000-D.PDF		PDF document containing the BOM for the assembly
BOM-SM1000-D.xls		Excel FIle of BOM-SM1000.sch
DRL-TAB-SM1000-D.pdf	Drill Table info for SM1000.brd
GBR-SM1000-D.PDF			PDF document of Gerber plots
LOC-SM1000-D.PDF	PDF document with part locations for the assembly
LOC-SM1000-D.XLS	EXCEL FILE OF LOCATION INFORMATION
SCH-SM1000-D.PDF	PDF document with schematic for the assembly
DIM-SM1000-D.PDF	PDF document with top layer dimensions
README.PDF			This file. 

NOTES:
Y or Yes in the Generic column of the BOM indicates that the part may be substituted with any part that meets the part definition.
Y in the ROHS column of the BOM indicates that the part must meet ROHS requirements.
All parts MUST be ROHS compliant.

